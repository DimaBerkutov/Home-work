/**
 * Created by Dima on 14.05.2017.
 */

var nikita = {
    name: 'Nikita',
    number: 380959848893,
    knowledge : ['Angular', 'React'],
    nikita_info: {
        skype: 'nikita5224',
        mail: 'nikita@qqq.gmail.com'
    },
    confirmation: true
};

console.log(nikita);
